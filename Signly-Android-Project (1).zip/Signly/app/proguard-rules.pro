# Signly ProGuard / R8 rules.
# Most defaults come from the AGP-bundled proguard-android-optimize.txt.
# Add project-specific keep rules below only when a real crash or missing
# class shows up in a release build — don't pre-emptively over-keep.

# Room: entities and DAOs are referenced via generated code + reflection
# for some Room internals; keep annotated classes safe from renaming.
-keep class com.signly.app.data.local.entity.** { *; }

# Hilt-generated components must not be obfuscated.
-keep class dagger.hilt.** { *; }
-keep class * extends dagger.hilt.android.internal.managers.ViewComponentManager { *; }

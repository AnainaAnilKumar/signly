package com.signly.app.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signly.app.data.repository.SignRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val isDarkModeOverrideEnabled: Boolean = false,
    val isResetConfirmationVisible: Boolean = false,
    val didResetJustSucceed: Boolean = false,
)

/**
 * Backs [SettingsScreen].
 *
 * TODO (not yet wired): [isDarkModeOverrideEnabled] currently lives only
 * in this ViewModel's in-memory state, so it resets to "follow system"
 * every process restart. Persisting it needs a small local key-value
 * store (Preferences DataStore is the standard choice) — deliberately
 * left out of this UI-design pass since it's a new Gradle dependency and
 * a DI module of its own, not a visual-design concern.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val signRepository: SignRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    fun setDarkModeOverride(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isDarkModeOverrideEnabled = enabled)
    }

    fun requestResetConfirmation() {
        _uiState.value = _uiState.value.copy(isResetConfirmationVisible = true)
    }

    fun dismissResetConfirmation() {
        _uiState.value = _uiState.value.copy(isResetConfirmationVisible = false)
    }

    fun confirmReset() {
        viewModelScope.launch {
            signRepository.clearAllLocalData()
            _uiState.value = _uiState.value.copy(
                isResetConfirmationVisible = false,
                didResetJustSucceed = true,
            )
        }
    }

    fun dismissResetSuccessMessage() {
        _uiState.value = _uiState.value.copy(didResetJustSucceed = false)
    }
}

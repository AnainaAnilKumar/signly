package com.signly.app.ui.theme

import androidx.compose.ui.graphics.Color

/*
 * Signly brand palette — sourced directly from the brand reference image:
 *   Purple       #A08DBD
 *   Light Purple #E4CCDB
 *   Yellow       #FED711
 *   Navy Blue    #3B2A70
 *
 * Role mapping (why each brand color maps where it does):
 * - Navy Blue -> primary. It's the darkest, most "anchored" color in the
 *   set, so it carries the app bar, primary buttons, and selected nav
 *   state.
 * - Purple -> secondary. Supporting accents, secondary buttons,
 *   unselected icon tint.
 * - Yellow -> tertiary. Reserved deliberately for the highest-attention
 *   moments only: correct-answer feedback in the quiz, streak/progress
 *   badges, the FAB. Overusing yellow would cheapen it; it should read
 *   as a spotlight, not a background color.
 * - Light Purple -> primary/secondary container tints, i.e. the soft
 *   card and section backgrounds throughout the app.
 */

// Raw brand colors — kept as named constants so any screen can reference
// the brand identity directly, not just through a semantic M3 role.
val BrandPurple = Color(0xFFA08DBD)
val BrandLightPurple = Color(0xFFE4CCDB)
val BrandYellow = Color(0xFFFED711)
val BrandNavy = Color(0xFF3B2A70)

// ---------- Light scheme ----------
val PrimaryLight = BrandNavy
val OnPrimaryLight = Color(0xFFFFFFFF)
val PrimaryContainerLight = BrandLightPurple
val OnPrimaryContainerLight = BrandNavy

val SecondaryLight = BrandPurple
val OnSecondaryLight = Color(0xFFFFFFFF)
val SecondaryContainerLight = Color(0xFFF3EAF6) // paler than PrimaryContainer, keeps the two containers visually distinct
val OnSecondaryContainerLight = BrandNavy

val TertiaryLight = BrandYellow
val OnTertiaryLight = BrandNavy
val TertiaryContainerLight = Color(0xFFFFF3B0)
val OnTertiaryContainerLight = Color(0xFF4A3F00)

val ErrorLight = Color(0xFFBA1A1A)
val OnErrorLight = Color(0xFFFFFFFF)
val ErrorContainerLight = Color(0xFFFFDAD6)
val OnErrorContainerLight = Color(0xFF410002)

val BackgroundLight = Color(0xFFFBF8FC)
val OnBackgroundLight = Color(0xFF1C1B1F)
val SurfaceLight = Color(0xFFFBF8FC)
val OnSurfaceLight = Color(0xFF1C1B1F)
val SurfaceVariantLight = Color(0xFFF1E9F3)
val OnSurfaceVariantLight = Color(0xFF4B4553)
val OutlineLight = Color(0xFF7C7589)

// ---------- Dark scheme ----------
val PrimaryDark = BrandPurple
val OnPrimaryDark = Color(0xFF1E1433)
val PrimaryContainerDark = Color(0xFF4A3580)
val OnPrimaryContainerDark = BrandLightPurple

val SecondaryDark = BrandLightPurple
val OnSecondaryDark = BrandNavy
val SecondaryContainerDark = Color(0xFF4A3F5C)
val OnSecondaryContainerDark = BrandLightPurple

val TertiaryDark = BrandYellow
val OnTertiaryDark = Color(0xFF2A1F4D)
val TertiaryContainerDark = Color(0xFF5C4E00)
val OnTertiaryContainerDark = Color(0xFFFCE388)

val ErrorDark = Color(0xFFFFB4AB)
val OnErrorDark = Color(0xFF690005)
val ErrorContainerDark = Color(0xFF93000A)
val OnErrorContainerDark = Color(0xFFFFDAD6)

val BackgroundDark = Color(0xFF1B1330)
val OnBackgroundDark = Color(0xFFECE6F5)
val SurfaceDark = Color(0xFF1B1330)
val OnSurfaceDark = Color(0xFFECE6F5)
val SurfaceVariantDark = Color(0xFF352F41)
val OnSurfaceVariantDark = Color(0xFFCFC6DB)
val OutlineDark = Color(0xFF988FA3)

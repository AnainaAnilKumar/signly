package com.signly.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.signly.app.ui.alphabet.AlphabetDetailScreen
import com.signly.app.ui.alphabet.AlphabetListScreen
import com.signly.app.ui.greetings.GreetingDetailScreen
import com.signly.app.ui.greetings.GreetingsListScreen
import com.signly.app.ui.home.HomeScreen
import com.signly.app.ui.progress.ProgressScreen
import com.signly.app.ui.quiz.QuizScreen
import com.signly.app.ui.quiz.ResultScreen
import com.signly.app.ui.settings.SettingsScreen
import com.signly.app.ui.splash.SplashScreen

/**
 * Root composable: a Scaffold whose bottom bar is shown only on the three
 * top-level destinations (Home/Progress/Settings), wrapping the NavHost
 * that carries every screen in the app.
 */
@Composable
fun SignlyRoot(
    navController: NavHostController = rememberNavController(),
) {
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    val showBottomBar = bottomNavScreens.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                SignlyBottomNavBar(navController = navController, currentRoute = currentRoute)
            }
        },
    ) { innerPadding ->
        // Each screen manages its own Scaffold/topBar internally (see e.g.
        // AlphabetListScreen), so only the bottom padding from *this*
        // outer Scaffold needs to be respected here to avoid double
        // top-bar padding.
        androidx.compose.foundation.layout.Box(
            modifier = androidx.compose.ui.Modifier.padding(bottom = innerPadding.calculateBottomPadding()),
        ) {
            SignlyNavGraph(navController = navController)
        }
    }
}

@Composable
private fun SignlyBottomNavBar(
    navController: NavHostController,
    currentRoute: String?,
) {
    NavigationBar {
        val items = listOf(
            Triple(Screen.Home, Icons.Filled.Home, "Home"),
            Triple(Screen.Progress, Icons.Filled.BarChart, "Progress"),
            Triple(Screen.Settings, Icons.Filled.Settings, "Settings"),
        )
        items.forEach { (screen, icon, label) ->
            NavigationBarItem(
                selected = currentRoute == screen.route,
                onClick = {
                    navController.navigate(screen.route) {
                        popUpTo(navController.graph.findStartDestination().id) {
                            saveState = true
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = { androidx.compose.material3.Icon(icon as ImageVector, contentDescription = label) },
                label = { androidx.compose.material3.Text(label) },
            )
        }
    }
}

@Composable
fun SignlyNavGraph(
    navController: NavHostController,
) {
    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route,
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                onTimeout = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                },
            )
        }

        composable(Screen.Home.route) {
            HomeScreen(
                onNavigateToAlphabet = { navController.navigate(Screen.AlphabetList.route) },
                onNavigateToGreetings = { navController.navigate(Screen.GreetingsList.route) },
                onNavigateToQuiz = { navController.navigate(Screen.Quiz.route) },
            )
        }

        composable(Screen.Progress.route) {
            ProgressScreen(
                onNavigateToAlphabet = { navController.navigate(Screen.AlphabetList.route) },
            )
        }

        composable(Screen.Settings.route) {
            SettingsScreen()
        }

        composable(Screen.AlphabetList.route) {
            AlphabetListScreen(
                onSignClick = { signId -> navController.navigate(Screen.AlphabetDetail.createRoute(signId)) },
                onNavigateUp = { navController.navigateUp() },
            )
        }

        composable(
            route = Screen.AlphabetDetail.route,
            arguments = listOf(navArgument(Screen.AlphabetDetail.ARG_SIGN_ID) { type = NavType.StringType }),
        ) { backStackEntry ->
            val signId = backStackEntry.arguments?.getString(Screen.AlphabetDetail.ARG_SIGN_ID).orEmpty()
            AlphabetDetailScreen(
                signId = signId,
                onNavigateUp = { navController.navigateUp() },
                onNavigateToSign = { nextId ->
                    // Replaces the current detail entry rather than pushing a
                    // new one, so tapping Next repeatedly doesn't grow an
                    // unbounded back stack of every letter visited.
                    navController.navigate(Screen.AlphabetDetail.createRoute(nextId)) {
                        popUpTo(Screen.AlphabetDetail.route) { inclusive = true }
                    }
                },
            )
        }

        composable(Screen.GreetingsList.route) {
            GreetingsListScreen(
                onSignClick = { signId -> navController.navigate(Screen.GreetingDetail.createRoute(signId)) },
                onNavigateUp = { navController.navigateUp() },
            )
        }

        composable(
            route = Screen.GreetingDetail.route,
            arguments = listOf(navArgument(Screen.GreetingDetail.ARG_SIGN_ID) { type = NavType.StringType }),
        ) { backStackEntry ->
            val signId = backStackEntry.arguments?.getString(Screen.GreetingDetail.ARG_SIGN_ID).orEmpty()
            GreetingDetailScreen(
                signId = signId,
                onNavigateUp = { navController.navigateUp() },
                onNavigateToSign = { nextId ->
                    navController.navigate(Screen.GreetingDetail.createRoute(nextId)) {
                        popUpTo(Screen.GreetingDetail.route) { inclusive = true }
                    }
                },
            )
        }

        composable(Screen.Quiz.route) {
            QuizScreen(
                onNavigateUp = { navController.navigateUp() },
                onQuizComplete = { score, total ->
                    navController.navigate(Screen.Result.createRoute(score, total)) {
                        popUpTo(Screen.Quiz.route) { inclusive = true }
                    }
                },
            )
        }

        composable(
            route = Screen.Result.route,
            arguments = listOf(
                navArgument(Screen.Result.ARG_SCORE) { type = NavType.IntType },
                navArgument(Screen.Result.ARG_TOTAL) { type = NavType.IntType },
            ),
        ) { backStackEntry ->
            val score = backStackEntry.arguments?.getInt(Screen.Result.ARG_SCORE) ?: 0
            val total = backStackEntry.arguments?.getInt(Screen.Result.ARG_TOTAL) ?: 0
            ResultScreen(
                score = score,
                total = total,
                onRetry = {
                    navController.navigate(Screen.Quiz.route) {
                        popUpTo(Screen.Home.route)
                    }
                },
                onBackToHome = {
                    navController.navigate(Screen.Home.route) {
                        popUpTo(Screen.Home.route) { inclusive = true }
                    }
                },
            )
        }
    }
}

package com.signly.app.data.model

/**
 * A single piece of learnable content — one alphabet letter (e.g. "A") or
 * one greeting (e.g. "Thank You").
 *
 * This is a plain, immutable data class: it has no Android framework
 * dependencies (no Context, no Resources) so it can be unit-tested and
 * reused across the data, domain, and UI layers without modification.
 *
 * @param id Stable, unique identifier used for navigation arguments and as
 *   the Room primary key for progress tracking (e.g. "alphabet_a",
 *   "greeting_thank_you"). Never change an existing id after release —
 *   NavGraph routes and any saved progress rows key off it.
 * @param label The display text shown to the user (e.g. "A", "Thank You").
 * @param category Which learning module this item belongs to.
 * @param imageRes Drawable resource id for the sign illustration. Left as
 *   a plain Int (Android resource id) rather than a resource *name* string,
 *   which is the standard, type-safe way to reference drawables from a
 *   data layer that still needs to stay decoupled from Compose.
 * @param description Short plain-text explanation of the hand position.
 *   Populated with real, ISL-reference-verified text during content
 *   entry — deliberately left as placeholder copy in [data.source] for now
 *   so inaccurate sign descriptions are never shipped by accident.
 */
data class SignItem(
    val id: String,
    val label: String,
    val category: SignCategory,
    val imageRes: Int,
    val description: String,
)

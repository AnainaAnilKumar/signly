package com.signly.app.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.signly.app.ui.common.SignlyTopAppBar
import kotlinx.coroutines.delay

/**
 * Settings — the third bottom-nav destination. Two settings rows (dark
 * mode, reset progress) plus an About row. Reset Progress is destructive
 * (wipes every viewed/practiced flag in Room), so it's gated behind an
 * AlertDialog confirmation rather than firing on a single tap.
 */
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    if (uiState.didResetJustSucceed) {
        LaunchedEffect(Unit) {
            delay(2000)
            viewModel.dismissResetSuccessMessage()
        }
    }

    Scaffold(
        topBar = { SignlyTopAppBar(title = "Settings") },
        snackbarHost = {
            if (uiState.didResetJustSucceed) {
                Snackbar(modifier = Modifier.padding(16.dp)) {
                    Text("Progress reset")
                }
            }
        },
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 20.dp,
                end = 20.dp,
                top = innerPadding.calculateTopPadding() + 20.dp,
                bottom = 20.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                SettingsRow(
                    icon = Icons.Filled.DarkMode,
                    title = "Dark Mode",
                    subtitle = "Override system theme",
                ) {
                    Switch(
                        checked = uiState.isDarkModeOverrideEnabled,
                        onCheckedChange = viewModel::setDarkModeOverride,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onPrimary,
                            checkedTrackColor = MaterialTheme.colorScheme.primary,
                        ),
                    )
                }
            }

            item {
                SettingsRow(
                    icon = Icons.Filled.DeleteForever,
                    title = "Reset Progress",
                    subtitle = "Clear viewed signs, favorites, and quiz history",
                    titleColor = MaterialTheme.colorScheme.error,
                    onClick = viewModel::requestResetConfirmation,
                )
            }

            item {
                SettingsRow(
                    icon = Icons.Filled.Info,
                    title = "About Signly",
                    subtitle = "Version 1.0.0 — offline ISL basics",
                )
            }
        }
    }

    if (uiState.isResetConfirmationVisible) {
        AlertDialog(
            onDismissRequest = viewModel::dismissResetConfirmation,
            title = { Text("Reset all progress?") },
            text = { Text("This clears every letter and greeting marked as viewed or practiced, all favorites, and your quiz score history. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = viewModel::confirmReset) {
                    Text("Reset", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = viewModel::dismissResetConfirmation) {
                    Text("Cancel")
                }
            },
        )
    }
}

@Composable
private fun SettingsRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    subtitle: String,
    titleColor: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurface,
    onClick: (() -> Unit)? = null,
    trailing: @Composable (() -> Unit)? = null,
) {
    Card(
        onClick = onClick ?: {},
        enabled = onClick != null,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = titleColor,
            )
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
            ) {
                Text(title, style = MaterialTheme.typography.titleMedium, color = titleColor)
                Text(
                    subtitle,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            trailing?.invoke()
        }
    }
}

package com.signly.app.di

import com.signly.app.data.repository.SignRepository
import com.signly.app.data.repository.SignRepositoryImpl
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Tells Hilt which concrete class to hand out whenever a [SignRepository]
 * is requested (e.g. in a ViewModel constructor).
 *
 * @Binds is used instead of @Provides here because SignRepositoryImpl has
 * an @Inject constructor Hilt can already call directly — @Binds just
 * tells Hilt "when someone asks for the interface, give them this impl,"
 * with no manual construction code needed. This module must be an
 * `abstract class` (not `object`) because @Binds functions are themselves
 * abstract.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class RepositoryModule {

    @Binds
    abstract fun bindSignRepository(
        impl: SignRepositoryImpl,
    ): SignRepository
}

package com.signly.app.ui.alphabet

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.signly.app.ui.common.LoadingState
import com.signly.app.ui.common.SignlyTopAppBar

/**
 * Alphabet Detail — one letter's illustration, label, and a plain-text
 * description of the hand position, plus Previous/Next controls to move
 * through the whole alphabet without returning to the grid each time.
 *
 * [signId] changing (via LaunchedEffect's key) is what re-triggers the
 * load when the user taps Next/Previous — the composable itself is never
 * destroyed and recreated between letters, only the ViewModel's loaded
 * sign changes.
 */
@Composable
fun AlphabetDetailScreen(
    signId: String,
    onNavigateUp: () -> Unit,
    onNavigateToSign: (String) -> Unit,
    viewModel: AlphabetDetailViewModel = hiltViewModel(),
) {
    val sign by viewModel.sign.collectAsState()
    val isFavorite by viewModel.isFavorite.collectAsState()

    LaunchedEffect(signId) {
        viewModel.loadSign(signId)
    }

    Scaffold(
        topBar = {
            SignlyTopAppBar(
                title = sign?.let { "Letter ${it.label}" } ?: "Loading...",
                onNavigateUp = onNavigateUp,
                actions = {
                    if (sign != null) {
                        IconButton(onClick = { viewModel.toggleFavorite() }) {
                            Icon(
                                imageVector = if (isFavorite) Icons.Filled.Star else Icons.Filled.StarBorder,
                                contentDescription = if (isFavorite) "Remove from favorites" else "Add to favorites",
                                tint = if (isFavorite) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface,
                            )
                        }
                    }
                },
            )
        },
    ) { innerPadding ->
        val currentSign = sign
        if (currentSign == null) {
            LoadingState(
                message = "Loading sign...",
                modifier = Modifier.padding(innerPadding),
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Image(
                    painter = painterResource(id = currentSign.imageRes),
                    contentDescription = "ISL sign for ${currentSign.label}",
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                        .padding(32.dp),
                )
            }

            Text(
                text = currentSign.label,
                style = MaterialTheme.typography.headlineLarge,
                color = MaterialTheme.colorScheme.onBackground,
            )

            Card(
                shape = MaterialTheme.shapes.medium,
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                ),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(
                    text = currentSign.description,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(16.dp),
                )
            }

            Button(
                onClick = { viewModel.markPracticed() },
                modifier = Modifier.fillMaxWidth(),
                colors = androidx.compose.material3.ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.tertiary,
                    contentColor = MaterialTheme.colorScheme.onTertiary,
                ),
            ) {
                Icon(Icons.Filled.CheckCircle, contentDescription = null)
                Text(" Mark as Practiced", modifier = Modifier.padding(start = 4.dp))
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                OutlinedButton(
                    onClick = { viewModel.previousSignId?.let(onNavigateToSign) },
                    enabled = viewModel.previousSignId != null,
                    modifier = Modifier.weight(1f),
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
                    Text(" Previous", modifier = Modifier.padding(start = 4.dp))
                }
                OutlinedButton(
                    onClick = { viewModel.nextSignId?.let(onNavigateToSign) },
                    enabled = viewModel.nextSignId != null,
                    modifier = Modifier.weight(1f),
                ) {
                    Text("Next ", modifier = Modifier.padding(end = 4.dp))
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

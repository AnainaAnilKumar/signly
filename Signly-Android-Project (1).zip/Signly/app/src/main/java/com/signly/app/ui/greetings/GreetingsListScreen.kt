package com.signly.app.ui.greetings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiPeople
import androidx.compose.material.icons.filled.WavingHand
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.signly.app.ui.common.EmptyState
import com.signly.app.ui.common.SignlyTopAppBar

/**
 * Greetings List — a vertical list (not a grid, unlike Alphabet) because
 * greeting labels are full phrases ("Good Morning") that need horizontal
 * room a 4-column grid cell wouldn't give them. Each row: icon, phrase,
 * viewed checkmark, chevron.
 */
@Composable
fun GreetingsListScreen(
    onSignClick: (String) -> Unit,
    onNavigateUp: () -> Unit,
    viewModel: GreetingsListViewModel = hiltViewModel(),
) {
    val entries by viewModel.entries.collectAsState()

    Scaffold(
        topBar = { SignlyTopAppBar(title = "Greetings", onNavigateUp = onNavigateUp) },
    ) { innerPadding ->
        if (entries.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.EmojiPeople,
                title = "No greetings available",
                message = "Greeting content couldn't be loaded. Try restarting the app.",
                modifier = Modifier.padding(innerPadding),
            )
            return@Scaffold
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 16.dp,
                bottom = 16.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(entries, key = { it.sign.id }) { entry ->
                GreetingRow(
                    label = entry.sign.label,
                    isViewed = entry.isViewed,
                    onClick = { onSignClick(entry.sign.id) },
                )
            }
        }
    }
}

@Composable
private fun GreetingRow(
    label: String,
    isViewed: Boolean,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (isViewed) {
                MaterialTheme.colorScheme.secondaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                imageVector = Icons.Filled.WavingHand,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
            )
            Text(
                text = label,
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp),
            )
            if (isViewed) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = "Viewed",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier.size(20.dp),
                )
            }
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSecondaryContainer,
                modifier = Modifier.padding(start = 8.dp),
            )
        }
    }
}

package com.signly.app.ui.progress

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signly.app.data.local.entity.QuizScoreEntity
import com.signly.app.data.model.SignCategory
import com.signly.app.data.repository.SignRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class CategoryProgress(
    val viewedCount: Int,
    val practicedCount: Int,
    val totalCount: Int,
) {
    val viewedFraction: Float get() = if (totalCount == 0) 0f else viewedCount / totalCount.toFloat()
}

data class QuizStats(
    val attemptCount: Int,
    val bestScore: QuizScoreEntity?,
) {
    val bestScorePercent: Int?
        get() = bestScore?.let { ((it.score.toFloat() / it.totalQuestions) * 100).toInt() }
}

data class ProgressUiState(
    val alphabet: CategoryProgress = CategoryProgress(0, 0, 0),
    val greetings: CategoryProgress = CategoryProgress(0, 0, 0),
    val favoritesCount: Int = 0,
    val quizStats: QuizStats = QuizStats(0, null),
) {
    val hasAnyProgress: Boolean get() = alphabet.viewedCount > 0 || greetings.viewedCount > 0
}

/**
 * Backs [ProgressScreen]. Combines FOUR independent Room-backed flows —
 * sign progress, favorites, quiz attempt count, best quiz score — into
 * one UI state object. [combine] (not nested collects) is the right tool
 * here: it re-emits a fresh [ProgressUiState] whenever ANY one of the
 * four sources changes, without the ViewModel manually wiring up each
 * combination by hand.
 */
@HiltViewModel
class ProgressViewModel @Inject constructor(
    signRepository: SignRepository,
) : ViewModel() {

    private val alphabetSigns = signRepository.getSignsByCategory(SignCategory.ALPHABET)
    private val greetingSigns = signRepository.getSignsByCategory(SignCategory.GREETING)

    val uiState: StateFlow<ProgressUiState> = combine(
        signRepository.observeAllProgress(),
        signRepository.observeAllFavorites(),
        signRepository.observeQuizAttemptCount(),
        signRepository.observeBestQuizScore(),
    ) { progressList, favorites, attemptCount, bestScore ->
        val viewedIds = progressList.filter { it.isViewed }.map { it.signId }.toSet()
        val practicedIds = progressList.filter { it.isPracticed }.map { it.signId }.toSet()

        ProgressUiState(
            alphabet = CategoryProgress(
                viewedCount = alphabetSigns.count { it.id in viewedIds },
                practicedCount = alphabetSigns.count { it.id in practicedIds },
                totalCount = alphabetSigns.size,
            ),
            greetings = CategoryProgress(
                viewedCount = greetingSigns.count { it.id in viewedIds },
                practicedCount = greetingSigns.count { it.id in practicedIds },
                totalCount = greetingSigns.size,
            ),
            favoritesCount = favorites.size,
            quizStats = QuizStats(attemptCount = attemptCount, bestScore = bestScore),
        )
    }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = ProgressUiState(
                alphabet = CategoryProgress(0, 0, alphabetSigns.size),
                greetings = CategoryProgress(0, 0, greetingSigns.size),
            ),
        )
}

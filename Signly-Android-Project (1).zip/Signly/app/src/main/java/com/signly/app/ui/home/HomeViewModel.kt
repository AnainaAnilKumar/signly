package com.signly.app.ui.home

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signly.app.data.repository.SignRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import javax.inject.Inject

data class HomeUiState(
    val totalSigns: Int = 0,
    val viewedCount: Int = 0,
)

@HiltViewModel
class HomeViewModel @Inject constructor(
    signRepository: SignRepository,
) : ViewModel() {

    private val totalSigns = signRepository.getAllSigns().size

    val uiState: StateFlow<HomeUiState> = signRepository.observeAllProgress()
        .map { progressList ->
            HomeUiState(
                totalSigns = totalSigns,
                viewedCount = progressList.count { it.isViewed },
            )
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = HomeUiState(totalSigns = totalSigns, viewedCount = 0),
        )
}

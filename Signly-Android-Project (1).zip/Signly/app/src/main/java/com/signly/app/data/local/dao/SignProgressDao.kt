package com.signly.app.data.local.dao

import androidx.room.Dao
import androidx.room.Query
import androidx.room.Upsert
import com.signly.app.data.local.entity.SignProgressEntity
import kotlinx.coroutines.flow.Flow

/** Covers both Alphabet progress and Greeting progress — see SignProgressEntity's KDoc for why this is one table/DAO, not two. */
@Dao
interface SignProgressDao {

    /**
     * Insert-or-update in one call. Room's @Upsert (since Room 2.5) is the
     * correct tool here rather than a separate @Insert(OnConflictStrategy.
     * REPLACE) — it's explicit about intent and slightly more efficient.
     */
    @Upsert
    suspend fun upsert(progress: SignProgressEntity)

    @Query("SELECT * FROM sign_progress WHERE sign_id = :signId")
    fun observeProgress(signId: String): Flow<SignProgressEntity?>

    @Query("SELECT * FROM sign_progress")
    fun observeAllProgress(): Flow<List<SignProgressEntity>>

    /** Backs the Settings screen's "Reset Progress" action — a plain local delete, no server call involved. */
    @Query("DELETE FROM sign_progress")
    suspend fun clearAll()
}

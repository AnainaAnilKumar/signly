package com.signly.app.ui.quiz

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.signly.app.ui.common.EmptyState
import com.signly.app.ui.common.SignlyTopAppBar

/**
 * Quiz — shows one sign illustration and 4 label choices; tapping a
 * choice immediately colors it correct (tertiary/yellow) or incorrect
 * (error/red), and reveals the correct answer if the user got it wrong.
 * "See Results" (last question) hands off to [onQuizComplete] with the
 * final score, rather than the screen owning result-navigation itself.
 */
@Composable
fun QuizScreen(
    onNavigateUp: () -> Unit,
    onQuizComplete: (score: Int, total: Int) -> Unit,
    viewModel: QuizViewModel = hiltViewModel(),
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = { SignlyTopAppBar(title = "Practice Quiz", onNavigateUp = onNavigateUp) },
    ) { innerPadding ->
        val question = uiState.currentQuestion
        if (question == null) {
            EmptyState(
                icon = Icons.Filled.Quiz,
                title = "No quiz questions available",
                message = "There isn't enough content yet to build a quiz.",
                modifier = Modifier.padding(innerPadding),
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp),
        ) {
            Column {
                Text(
                    text = "Question ${uiState.currentIndex + 1} of ${uiState.questions.size}",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                LinearProgressIndicator(
                    progress = { (uiState.currentIndex + 1) / uiState.questions.size.toFloat() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    color = MaterialTheme.colorScheme.tertiary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
            }

            Card(
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Image(
                    painter = painterResource(id = question.sign.imageRes),
                    contentDescription = "Which sign is this?",
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.3f)
                        .padding(24.dp),
                )
            }

            Text(
                text = "What does this sign mean?",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )

            question.options.forEach { option ->
                AnswerOptionCard(
                    label = option,
                    correctLabel = question.sign.label,
                    selectedOption = uiState.selectedOption,
                    onClick = { viewModel.selectAnswer(option) },
                )
            }

            if (uiState.hasAnswered) {
                Button(
                    onClick = {
                        if (uiState.isLastQuestion) {
                            viewModel.finishQuiz()
                            onQuizComplete(uiState.score, uiState.questions.size)
                        } else {
                            viewModel.goToNextQuestion()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(if (uiState.isLastQuestion) "See Results" else "Next Question")
                }
            }
        }
    }
}

/**
 * A single tappable answer choice. Once an answer has been selected for
 * this question (selectedOption != null), every option becomes
 * non-interactive and recolors to reveal right/wrong — this is what
 * "instant feedback" means for FR-7.
 */
@Composable
private fun AnswerOptionCard(
    label: String,
    correctLabel: String,
    selectedOption: String?,
    onClick: () -> Unit,
) {
    val hasAnswered = selectedOption != null
    val isThisCorrect = label == correctLabel
    val isThisSelected = label == selectedOption

    val targetColor = when {
        !hasAnswered -> MaterialTheme.colorScheme.surfaceVariant
        isThisCorrect -> MaterialTheme.colorScheme.tertiaryContainer
        isThisSelected -> MaterialTheme.colorScheme.errorContainer
        else -> MaterialTheme.colorScheme.surfaceVariant
    }
    val containerColor by animateColorAsState(targetColor, label = "answer-option-color")

    val contentColor = when {
        !hasAnswered -> MaterialTheme.colorScheme.onSurfaceVariant
        isThisCorrect -> MaterialTheme.colorScheme.onTertiaryContainer
        isThisSelected -> MaterialTheme.colorScheme.onErrorContainer
        else -> MaterialTheme.colorScheme.onSurfaceVariant
    }

    Card(
        onClick = onClick,
        enabled = !hasAnswered,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = containerColor),
        modifier = Modifier.fillMaxWidth(),
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.titleMedium,
            color = contentColor,
            modifier = Modifier.padding(16.dp),
        )
    }
}

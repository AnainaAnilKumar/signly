package com.signly.app

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point.
 *
 * @HiltAndroidApp triggers Hilt's code generation and creates the top-level
 * (application-scoped) dependency container that every other Hilt component
 * in the app (activities, view models) hangs off of. Every Hilt-using app
 * needs exactly one class annotated like this, and it must be registered
 * in AndroidManifest.xml via android:name=".SignlyApplication".
 */
@HiltAndroidApp
class SignlyApplication : Application()

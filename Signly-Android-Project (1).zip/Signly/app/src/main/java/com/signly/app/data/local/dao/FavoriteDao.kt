package com.signly.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.signly.app.data.local.entity.FavoriteEntity
import kotlinx.coroutines.flow.Flow

/**
 * Favorites are modeled as "row exists = favorited" (see FavoriteEntity's
 * KDoc) rather than a boolean column — so adding is a plain insert,
 * removing is a plain delete by id, and "is this favorited?" is an
 * EXISTS query Room can map straight onto a Flow<Boolean>.
 */
@Dao
interface FavoriteDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun add(favorite: FavoriteEntity)

    @Query("DELETE FROM favorites WHERE sign_id = :signId")
    suspend fun remove(signId: String)

    @Query("SELECT EXISTS(SELECT 1 FROM favorites WHERE sign_id = :signId)")
    fun observeIsFavorite(signId: String): Flow<Boolean>

    @Query("SELECT * FROM favorites ORDER BY added_at_epoch_millis DESC")
    fun observeAllFavorites(): Flow<List<FavoriteEntity>>

    /** Backs the Settings screen's "Reset Progress" action. */
    @Query("DELETE FROM favorites")
    suspend fun clearAll()
}

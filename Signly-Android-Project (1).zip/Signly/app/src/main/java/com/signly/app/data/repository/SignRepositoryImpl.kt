package com.signly.app.data.repository

import com.signly.app.data.local.dao.FavoriteDao
import com.signly.app.data.local.dao.QuizScoreDao
import com.signly.app.data.local.dao.SignProgressDao
import com.signly.app.data.local.entity.FavoriteEntity
import com.signly.app.data.local.entity.QuizScoreEntity
import com.signly.app.data.local.entity.SignProgressEntity
import com.signly.app.data.model.SignCategory
import com.signly.app.data.model.SignItem
import com.signly.app.data.source.SignDataSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SignRepositoryImpl @Inject constructor(
    private val signDataSource: SignDataSource,
    private val signProgressDao: SignProgressDao,
    private val favoriteDao: FavoriteDao,
    private val quizScoreDao: QuizScoreDao,
) : SignRepository {

    // ---------- Static content ----------

    override fun getAllSigns(): List<SignItem> =
        signDataSource.getAllSigns()

    override fun getSignsByCategory(category: SignCategory): List<SignItem> =
        signDataSource.getAllSigns().filter { it.category == category }

    override fun getSignById(id: String): SignItem? =
        signDataSource.getAllSigns().firstOrNull { it.id == id }

    // ---------- Sign progress ----------

    override fun observeProgress(signId: String): Flow<SignProgressEntity?> =
        signProgressDao.observeProgress(signId)

    override fun observeAllProgress(): Flow<List<SignProgressEntity>> =
        signProgressDao.observeAllProgress()

    override fun observeProgressByCategory(category: SignCategory): Flow<List<SignProgressEntity>> {
        val idsInCategory = getSignsByCategory(category).map { it.id }.toSet()
        return signProgressDao.observeAllProgress()
            .map { allProgress -> allProgress.filter { it.signId in idsInCategory } }
    }

    override suspend fun markSignAsViewed(signId: String) {
        signProgressDao.upsert(
            SignProgressEntity(signId = signId, isViewed = true)
        )
    }

    override suspend fun markSignAsPracticed(signId: String) {
        // Preserve isViewed=true regardless: a sign can't be practiced
        // without having been viewed first in this app's flow, and we
        // never want a practiced row to accidentally read as "not viewed".
        signProgressDao.upsert(
            SignProgressEntity(signId = signId, isViewed = true, isPracticed = true)
        )
    }

    // ---------- Favorites ----------

    override fun observeIsFavorite(signId: String): Flow<Boolean> =
        favoriteDao.observeIsFavorite(signId)

    override fun observeAllFavorites(): Flow<List<FavoriteEntity>> =
        favoriteDao.observeAllFavorites()

    override suspend fun toggleFavorite(signId: String) {
        val isCurrentlyFavorite = favoriteDao.observeIsFavorite(signId).first()
        if (isCurrentlyFavorite) {
            favoriteDao.remove(signId)
        } else {
            favoriteDao.add(FavoriteEntity(signId = signId))
        }
    }

    // ---------- Quiz scores ----------

    override fun observeAllQuizScores(): Flow<List<QuizScoreEntity>> =
        quizScoreDao.observeAllScores()

    override fun observeBestQuizScore(): Flow<QuizScoreEntity?> =
        quizScoreDao.observeBestScore()

    override fun observeQuizAttemptCount(): Flow<Int> =
        quizScoreDao.observeAttemptCount()

    override suspend fun saveQuizScore(score: Int, totalQuestions: Int) {
        quizScoreDao.insert(QuizScoreEntity(score = score, totalQuestions = totalQuestions))
    }

    // ---------- Maintenance ----------

    override suspend fun clearAllLocalData() {
        signProgressDao.clearAll()
        favoriteDao.clearAll()
        quizScoreDao.clearAll()
    }
}

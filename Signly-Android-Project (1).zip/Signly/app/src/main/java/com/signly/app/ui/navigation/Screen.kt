package com.signly.app.ui.navigation

/**
 * Every navigable destination in Signly, in one place. Using a sealed
 * class instead of raw string routes scattered across composables means
 * a typo in a route name is a compile error, not a silent runtime crash
 * when NavController can't find a matching destination.
 */
sealed class Screen(val route: String) {

    data object Splash : Screen("splash")

    // --- Bottom navigation destinations (top-level, no back arrow) ---
    data object Home : Screen("home")
    data object Progress : Screen("progress")
    data object Settings : Screen("settings")

    // --- Alphabet flow ---
    data object AlphabetList : Screen("alphabet_list")
    data object AlphabetDetail : Screen("alphabet_detail/{signId}") {
        const val ARG_SIGN_ID = "signId"
        fun createRoute(signId: String) = "alphabet_detail/$signId"
    }

    // --- Greetings flow ---
    data object GreetingsList : Screen("greetings_list")
    data object GreetingDetail : Screen("greeting_detail/{signId}") {
        const val ARG_SIGN_ID = "signId"
        fun createRoute(signId: String) = "greeting_detail/$signId"
    }

    // --- Practice flow ---
    data object Quiz : Screen("quiz")
    data object Result : Screen("result/{score}/{total}") {
        const val ARG_SCORE = "score"
        const val ARG_TOTAL = "total"
        fun createRoute(score: Int, total: Int) = "result/$score/$total"
    }
}

/** The three destinations shown in the bottom navigation bar, in display order. */
val bottomNavScreens = listOf(Screen.Home, Screen.Progress, Screen.Settings)

package com.signly.app.ui.greetings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signly.app.data.model.SignCategory
import com.signly.app.data.model.SignItem
import com.signly.app.data.repository.SignRepository
import com.signly.app.ui.alphabet.SignListEntry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** Backs [GreetingsListScreen]. See AlphabetViewModel for the pattern this mirrors. */
@HiltViewModel
class GreetingsListViewModel @Inject constructor(
    signRepository: SignRepository,
) : ViewModel() {

    private val greetingSigns = signRepository.getSignsByCategory(SignCategory.GREETING)

    val entries: StateFlow<List<SignListEntry>> = signRepository.observeAllProgress()
        .map { progressList ->
            val viewedIds = progressList.filter { it.isViewed }.map { it.signId }.toSet()
            greetingSigns.map { sign -> SignListEntry(sign, isViewed = sign.id in viewedIds) }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = greetingSigns.map { SignListEntry(it, isViewed = false) },
        )
}

/** Backs [GreetingDetailScreen]. See AlphabetDetailViewModel for the pattern this mirrors, including the favorite-tracking flatMapLatest. */
@HiltViewModel
class GreetingDetailViewModel @Inject constructor(
    private val signRepository: SignRepository,
) : ViewModel() {

    private val allGreetingSigns = signRepository.getSignsByCategory(SignCategory.GREETING)

    private val _sign = MutableStateFlow<SignItem?>(null)
    val sign: StateFlow<SignItem?> = _sign.asStateFlow()

    val isFavorite: StateFlow<Boolean> = _sign
        .filterNotNull()
        .flatMapLatest { sign -> signRepository.observeIsFavorite(sign.id) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false,
        )

    val previousSignId: String?
        get() = neighbor(-1)

    val nextSignId: String?
        get() = neighbor(+1)

    private fun neighbor(offset: Int): String? {
        val currentId = _sign.value?.id ?: return null
        val currentIndex = allGreetingSigns.indexOfFirst { it.id == currentId }
        if (currentIndex == -1) return null
        return allGreetingSigns.getOrNull(currentIndex + offset)?.id
    }

    fun loadSign(signId: String) {
        _sign.value = allGreetingSigns.firstOrNull { it.id == signId }
        viewModelScope.launch {
            signRepository.markSignAsViewed(signId)
        }
    }

    fun markPracticed() {
        val signId = _sign.value?.id ?: return
        viewModelScope.launch {
            signRepository.markSignAsPracticed(signId)
        }
    }

    fun toggleFavorite() {
        val signId = _sign.value?.id ?: return
        viewModelScope.launch {
            signRepository.toggleFavorite(signId)
        }
    }
}

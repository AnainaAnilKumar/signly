package com.signly.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.signly.app.data.local.dao.FavoriteDao
import com.signly.app.data.local.dao.QuizScoreDao
import com.signly.app.data.local.dao.SignProgressDao
import com.signly.app.data.local.entity.FavoriteEntity
import com.signly.app.data.local.entity.QuizScoreEntity
import com.signly.app.data.local.entity.SignProgressEntity

/**
 * The app's single Room database — three tables, all purely local, all
 * backing on-device-only features (FR-12, and the Favorites/Quiz-history
 * enhancements): sign_progress, favorites, quiz_scores.
 *
 * No singleton-via-companion-object pattern here: the single instance is
 * guaranteed instead by Hilt (@Singleton scope in di/DatabaseModule.kt).
 *
 * version = 1: this schema has not shipped to a real device yet (Signly
 * is still pre-release), so there is no installed base to migrate from —
 * adding/changing tables right now is a direct schema edit, not a
 * migration. The FIRST schema change made AFTER a real release ships
 * will need a real androidx.room.migration.Migration object and a version
 * bump; silently changing columns on a shipped version 1 would corrupt or
 * wipe real users' local progress.
 */
@Database(
    entities = [
        SignProgressEntity::class,
        FavoriteEntity::class,
        QuizScoreEntity::class,
    ],
    version = 1,
    exportSchema = true,
)
abstract class SignlyDatabase : RoomDatabase() {
    abstract fun signProgressDao(): SignProgressDao
    abstract fun favoriteDao(): FavoriteDao
    abstract fun quizScoreDao(): QuizScoreDao
}

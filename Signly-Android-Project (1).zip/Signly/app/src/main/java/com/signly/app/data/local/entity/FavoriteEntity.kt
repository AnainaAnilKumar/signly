package com.signly.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per sign the user has marked as a favorite. Presence of a row
 * = favorited; there is no boolean column — removing the favorite deletes
 * the row (see FavoriteDao.remove). This mirrors how a "starred items"
 * table is normally modeled: existence is the state, not a flag.
 *
 * @param signId Matches [com.signly.app.data.model.SignItem.id], same
 *   convention as [SignProgressEntity.signId] — a foreign-key-by-
 *   convention, not an enforced Room ForeignKey, since the sign catalog
 *   itself lives in code (SignDataSource), not in the database.
 */
@Entity(tableName = "favorites")
data class FavoriteEntity(
    @PrimaryKey
    @ColumnInfo(name = "sign_id")
    val signId: String,

    @ColumnInfo(name = "added_at_epoch_millis")
    val addedAtEpochMillis: Long = System.currentTimeMillis(),
)

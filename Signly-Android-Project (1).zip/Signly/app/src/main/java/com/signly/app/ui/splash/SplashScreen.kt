package com.signly.app.ui.splash

import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PanTool
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.signly.app.ui.common.rememberInfiniteRotation
import com.signly.app.ui.theme.BrandLightPurple
import com.signly.app.ui.theme.BrandNavy
import com.signly.app.ui.theme.BrandYellow
import kotlinx.coroutines.delay

/**
 * Splash screen shown once on cold start. This is a fixed-duration brand
 * moment, not a loading gate — Signly has no network/large-asset init to
 * wait on, so the delay exists purely for brand presence (short, so it
 * never feels like the app is stalling). [onTimeout] is called once, after
 * which the nav graph pops Splash off the back stack permanently.
 *
 * Motion: one slow, ambient rotating ring behind the glyph, plus a single
 * fade+scale entrance for the wordmark. Deliberately not layering in
 * additional effects — see the design brief's motion guidance.
 */
@Composable
fun SplashScreen(
    onTimeout: () -> Unit,
    splashDurationMillis: Long = 1400L,
) {
    val ringRotation = rememberInfiniteRotation(durationMillis = 9000)

    var isVisible by remember { mutableStateOf(false) }
    val entranceAlpha by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0f,
        animationSpec = tween(600, easing = LinearOutSlowInEasing),
        label = "splash-entrance-alpha",
    )
    val entranceScale by animateFloatAsState(
        targetValue = if (isVisible) 1f else 0.85f,
        animationSpec = tween(600, easing = LinearOutSlowInEasing),
        label = "splash-entrance-scale",
    )

    LaunchedEffect(Unit) {
        isVisible = true
        delay(splashDurationMillis)
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BrandNavy),
        contentAlignment = Alignment.Center,
    ) {
        // Ambient rotating ring — a simple circle outline in the brand's
        // lightest tint, sitting behind the glyph at low opacity.
        Box(
            modifier = Modifier
                .size(220.dp)
                .rotate(ringRotation)
                .alpha(0.25f)
                .background(Color.Transparent),
        ) {
            Surface(
                modifier = Modifier.size(220.dp),
                shape = CircleShape,
                color = Color.Transparent,
                border = androidx.compose.foundation.BorderStroke(2.dp, BrandLightPurple),
            ) {}
        }

        Column(
            modifier = Modifier
                .graphicsLayer {
                    alpha = entranceAlpha
                    scaleX = entranceScale
                    scaleY = entranceScale
                }
                .padding(PaddingValues(24.dp)),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Surface(
                shape = CircleShape,
                color = BrandYellow,
            ) {
                Icon(
                    imageVector = Icons.Filled.PanTool,
                    contentDescription = null,
                    tint = BrandNavy,
                    modifier = Modifier
                        .size(88.dp)
                        .padding(20.dp),
                )
            }
            Text(
                text = "Signly",
                style = MaterialTheme.typography.displayMedium,
                color = Color.White,
                modifier = Modifier.padding(top = 20.dp),
            )
            Text(
                text = "Learn Indian Sign Language",
                style = MaterialTheme.typography.bodyLarge,
                color = BrandLightPurple,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}

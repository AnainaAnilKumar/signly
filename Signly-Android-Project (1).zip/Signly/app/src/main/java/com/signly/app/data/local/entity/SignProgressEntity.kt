package com.signly.app.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * One row per sign the user has interacted with — covers BOTH Alphabet
 * progress and Greeting progress in a single table, rather than two
 * near-identical tables. The two feature requirements ("store alphabet
 * progress" / "store greeting progress") are satisfied by this one table
 * because [signId] already encodes which category a row belongs to (e.g.
 * "alphabet_a" vs "greeting_hello" — see SignDataSource's id scheme), and
 * the repository filters by category using that id + the static catalog
 * whenever a screen needs "alphabet-only" or "greetings-only" progress.
 * Splitting this into two physical tables would duplicate every column,
 * every DAO query, and every migration forever after — normalizing it
 * into one table is the standard relational-design choice here.
 *
 * @param signId Matches [com.signly.app.data.model.SignItem.id]. This is
 *   a foreign-key-by-convention, not an enforced Room ForeignKey, since
 *   the sign catalog itself lives in code (SignDataSource), not in a
 *   database table.
 */
@Entity(tableName = "sign_progress")
data class SignProgressEntity(
    @PrimaryKey
    @ColumnInfo(name = "sign_id")
    val signId: String,

    @ColumnInfo(name = "is_viewed")
    val isViewed: Boolean = false,

    @ColumnInfo(name = "is_practiced")
    val isPracticed: Boolean = false,

    @ColumnInfo(name = "last_updated_epoch_millis")
    val lastUpdatedEpochMillis: Long = System.currentTimeMillis(),
)

package com.signly.app.data.source

import com.signly.app.R
import com.signly.app.data.model.SignCategory
import com.signly.app.data.model.SignItem
import javax.inject.Inject
import javax.inject.Singleton

/**
 * The single source of truth for Signly's static content: 26 alphabet
 * signs + 10 greeting signs, hardcoded in Kotlin rather than parsed from a
 * bundled JSON/asset file.
 *
 * Why hardcoded Kotlin instead of a JSON asset: the content is small,
 * fixed at build time, and never changes at runtime — a JSON+Gson/kotlinx-
 * serialization pipeline would add a parsing step and a dependency for no
 * real benefit here. If the content set grows large (hundreds of entries)
 * or needs to be edited by a non-developer, revisit this and move it to a
 * bundled JSON asset parsed once at app start.
 *
 * Content note: `description` strings below are intentionally generic
 * placeholders ("Hand sign for the letter A"), NOT verified ISL hand-shape
 * instructions. Real descriptions must be written/reviewed against an
 * authoritative ISL reference (e.g. ISLRTC materials) before this app
 * ships — publishing inaccurate sign-language instructions would actively
 * mislead learners. Same applies to `imageRes`: every entry currently
 * points at the placeholder launcher glyph and must be replaced with a
 * real per-sign illustration during the content/asset phase.
 */
@Singleton
class SignDataSource @Inject constructor() {

    fun getAllSigns(): List<SignItem> = alphabetSigns + greetingSigns

    private val alphabetSigns: List<SignItem> = ('A'..'Z').map { letter ->
        SignItem(
            id = "alphabet_${letter.lowercaseChar()}",
            label = letter.toString(),
            category = SignCategory.ALPHABET,
            imageRes = R.drawable.ic_launcher_foreground, // TODO: replace with real sign illustration
            description = "Placeholder description for the letter $letter — verify against an ISL reference before release.",
        )
    }

    private val greetingSigns: List<SignItem> = listOf(
        "Hello" to "hello",
        "Thank You" to "thank_you",
        "Sorry" to "sorry",
        "Please" to "please",
        "Yes" to "yes",
        "No" to "no",
        "Good Morning" to "good_morning",
        "Goodbye" to "goodbye",
        "Help" to "help",
        "Welcome" to "welcome",
    ).map { (label, slug) ->
        SignItem(
            id = "greeting_$slug",
            label = label,
            category = SignCategory.GREETING,
            imageRes = R.drawable.ic_launcher_foreground, // TODO: replace with real sign illustration
            description = "Placeholder description for \"$label\" — verify against an ISL reference before release.",
        )
    }
}

package com.signly.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

/*
 * Rounded, soft corners throughout — deliberate choice given the brand
 * palette leans friendly/educational (pastel purple + bright yellow)
 * rather than corporate/sharp. Sharper corners (0-4dp) would clash with
 * that tone.
 */
val SignlyShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),   // chips, badges
    small = RoundedCornerShape(8.dp),        // small buttons
    medium = RoundedCornerShape(16.dp),      // standard cards
    large = RoundedCornerShape(24.dp),       // hero/category cards, dialogs
    extraLarge = RoundedCornerShape(32.dp),  // bottom sheets, splash mark
)

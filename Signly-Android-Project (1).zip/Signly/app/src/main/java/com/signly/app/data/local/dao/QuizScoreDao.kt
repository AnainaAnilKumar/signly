package com.signly.app.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.signly.app.data.local.entity.QuizScoreEntity
import kotlinx.coroutines.flow.Flow

/**
 * Append-only: every completed quiz attempt gets its own row (see
 * QuizScoreEntity's KDoc), so there is no upsert/update here — only
 * insert, read, and a full clear for Settings' reset action.
 */
@Dao
interface QuizScoreDao {

    @Insert
    suspend fun insert(quizScore: QuizScoreEntity)

    @Query("SELECT * FROM quiz_scores ORDER BY completed_at_epoch_millis DESC")
    fun observeAllScores(): Flow<List<QuizScoreEntity>>

    /**
     * Best attempt by accuracy (score / total_questions), not by raw score —
     * a 9/10 attempt should outrank a 10/15 attempt despite the lower raw
     * number. SQLite has no built-in "best by computed ratio" shortcut, so
     * the ratio is computed in the ORDER BY expression itself.
     */
    @Query("SELECT * FROM quiz_scores ORDER BY (score * 1.0 / total_questions) DESC LIMIT 1")
    fun observeBestScore(): Flow<QuizScoreEntity?>

    @Query("SELECT COUNT(*) FROM quiz_scores")
    fun observeAttemptCount(): Flow<Int>

    /** Backs the Settings screen's "Reset Progress" action. */
    @Query("DELETE FROM quiz_scores")
    suspend fun clearAll()
}

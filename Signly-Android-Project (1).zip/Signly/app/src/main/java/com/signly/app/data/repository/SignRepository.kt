package com.signly.app.data.repository

import com.signly.app.data.local.entity.FavoriteEntity
import com.signly.app.data.local.entity.QuizScoreEntity
import com.signly.app.data.local.entity.SignProgressEntity
import com.signly.app.data.model.SignCategory
import com.signly.app.data.model.SignItem
import kotlinx.coroutines.flow.Flow

/**
 * Single point of access to everything Signly persists or serves: static
 * sign content, per-sign progress, favorites, and quiz score history.
 * ViewModels depend on this interface, never on the DAOs or SignDataSource
 * directly — that indirection is what lets any one data source change
 * without touching a single ViewModel.
 */
interface SignRepository {

    // ---------- Static content (no persistence, no I/O) ----------

    /** All 36 signs, static content, returned instantly (in-memory, no I/O). */
    fun getAllSigns(): List<SignItem>

    /** Signs filtered to one category — backs the Alphabet/Greetings list screens. */
    fun getSignsByCategory(category: SignCategory): List<SignItem>

    /** A single sign by id, or null if the id doesn't match any known sign. */
    fun getSignById(id: String): SignItem?

    // ---------- Sign progress (covers BOTH Alphabet and Greeting progress — see SignProgressEntity's KDoc) ----------

    /** Reactive progress row for one sign; null if never marked viewed/practiced. */
    fun observeProgress(signId: String): Flow<SignProgressEntity?>

    /** Reactive progress for every sign the user has interacted with, across both categories. */
    fun observeAllProgress(): Flow<List<SignProgressEntity>>

    /** Reactive progress filtered to one category — e.g. "just the 26 alphabet rows." */
    fun observeProgressByCategory(category: SignCategory): Flow<List<SignProgressEntity>>

    /** Marks a sign as viewed (called when the user opens its detail screen). */
    suspend fun markSignAsViewed(signId: String)

    /** Marks a sign as practiced (called from the "Mark as Practiced" button). */
    suspend fun markSignAsPracticed(signId: String)

    // ---------- Favorites ----------

    /** True the instant a sign is favorited/unfavorited — drives a detail screen's star icon. */
    fun observeIsFavorite(signId: String): Flow<Boolean>

    /** Every favorited sign's row, most recently added first. */
    fun observeAllFavorites(): Flow<List<FavoriteEntity>>

    /** Adds the favorite if absent, removes it if present — the detail screen's star button calls this on every tap. */
    suspend fun toggleFavorite(signId: String)

    // ---------- Quiz scores ----------

    /** Every completed quiz attempt, most recent first. */
    fun observeAllQuizScores(): Flow<List<QuizScoreEntity>>

    /** The single highest-accuracy attempt on record, or null if the user has never completed a quiz. */
    fun observeBestQuizScore(): Flow<QuizScoreEntity?>

    /** How many quiz attempts the user has completed in total. */
    fun observeQuizAttemptCount(): Flow<Int>

    /** Records one completed quiz attempt. Called once, when the user reaches the Result screen. */
    suspend fun saveQuizScore(score: Int, totalQuestions: Int)

    // ---------- Maintenance ----------

    /** Wipes every local table: sign progress, favorites, and quiz history. Backs Settings' "Reset Progress" action. */
    suspend fun clearAllLocalData()
}

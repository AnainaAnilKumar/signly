package com.signly.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import dagger.hilt.android.AndroidEntryPoint
import com.signly.app.ui.navigation.SignlyRoot
import com.signly.app.ui.theme.SignlyTheme

/**
 * Signly is a single-activity app: MainActivity is the only Activity, and
 * every screen is a Composable destination inside [SignlyRoot]. This is
 * the standard modern Android pattern — screens are not separate Activities.
 *
 * @AndroidEntryPoint lets this Activity (and the ViewModels it hosts via
 * `hiltViewModel()`) receive dependencies from the Hilt graph started in
 * [SignlyApplication].
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            SignlyTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SignlyRoot()
                }
            }
        }
    }
}

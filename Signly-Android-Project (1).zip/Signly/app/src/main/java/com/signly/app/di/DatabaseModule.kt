package com.signly.app.di

import android.content.Context
import androidx.room.Room
import com.signly.app.data.local.SignlyDatabase
import com.signly.app.data.local.dao.FavoriteDao
import com.signly.app.data.local.dao.QuizScoreDao
import com.signly.app.data.local.dao.SignProgressDao
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * Provides the Room database and every DAO to the rest of the app.
 *
 * @Module + @InstallIn(SingletonComponent::class): these provided objects
 * live for the whole app process — exactly right for a database handle,
 * which must never have more than one instance open at a time.
 *
 * @Provides (not @Binds) is used because Room.databaseBuilder(...).build()
 * is a builder call we have to execute ourselves, not a plain constructor
 * Hilt can call for us.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideSignlyDatabase(
        @ApplicationContext context: Context,
    ): SignlyDatabase =
        Room.databaseBuilder(
            context,
            SignlyDatabase::class.java,
            "signly.db",
        )
            // Dev-only convenience: wipes and recreates the DB on a schema
            // change instead of crashing when no Migration is defined. Safe
            // right now only because Signly is pre-release (see
            // SignlyDatabase's KDoc) — MUST be replaced with a real
            // Migration before any version bump after a real release.
            .fallbackToDestructiveMigration()
            .build()

    @Provides
    @Singleton
    fun provideSignProgressDao(database: SignlyDatabase): SignProgressDao =
        database.signProgressDao()

    @Provides
    @Singleton
    fun provideFavoriteDao(database: SignlyDatabase): FavoriteDao =
        database.favoriteDao()

    @Provides
    @Singleton
    fun provideQuizScoreDao(database: SignlyDatabase): QuizScoreDao =
        database.quizScoreDao()
}

package com.signly.app.ui.quiz

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.signly.app.ui.common.SignlyTopAppBar

/**
 * Result — shown once, right after the last quiz question. Deliberately
 * has no ViewModel: score/total arrive as plain navigation arguments (see
 * Screen.Result), because this screen has nothing to load or persist —
 * it's a pure summary view of numbers the Quiz flow already computed.
 */
@Composable
fun ResultScreen(
    score: Int,
    total: Int,
    onRetry: () -> Unit,
    onBackToHome: () -> Unit,
) {
    val percentage = if (total > 0) score.toFloat() / total.toFloat() else 0f
    val (message, subMessage) = resultMessageFor(percentage)

    Scaffold(
        topBar = { SignlyTopAppBar(title = "Quiz Results") },
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Box(contentAlignment = Alignment.Center) {
                CircularProgressIndicator(
                    progress = { percentage },
                    modifier = Modifier.size(160.dp),
                    strokeWidth = 12.dp,
                    color = MaterialTheme.colorScheme.tertiary,
                    trackColor = MaterialTheme.colorScheme.surfaceVariant,
                )
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "$score/$total",
                        style = MaterialTheme.typography.headlineLarge,
                        color = MaterialTheme.colorScheme.onBackground,
                    )
                    Text(
                        text = "correct",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }

            Text(
                text = message,
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 24.dp),
            )
            Text(
                text = subMessage,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 8.dp),
            )

            Button(
                onClick = onRetry,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 32.dp),
            ) {
                Text("Try Again")
            }
            OutlinedButton(
                onClick = onBackToHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
            ) {
                Text("Back to Home")
            }
        }
    }
}

/** Plain-language performance message — no jargon, matches the interface's voice guidance. */
private fun resultMessageFor(percentage: Float): Pair<String, String> = when {
    percentage >= 0.8f -> "Excellent work!" to "You're well on your way to mastering ISL."
    percentage >= 0.5f -> "Good effort!" to "Review the signs you missed and try again."
    else -> "Keep practicing!" to "Revisit the Alphabet and Greetings screens, then try again."
}

package com.signly.app.ui.quiz

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signly.app.data.model.SignItem
import com.signly.app.data.repository.SignRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val QUESTION_COUNT = 10
private const val OPTIONS_PER_QUESTION = 4

/** One question: a sign to display, and the shuffled multiple-choice labels for it. */
data class QuizQuestion(
    val sign: SignItem,
    val options: List<String>,
)

data class QuizUiState(
    val questions: List<QuizQuestion> = emptyList(),
    val currentIndex: Int = 0,
    val selectedOption: String? = null,
    val score: Int = 0,
) {
    val currentQuestion: QuizQuestion? get() = questions.getOrNull(currentIndex)
    val isLastQuestion: Boolean get() = currentIndex == questions.lastIndex
    val hasAnswered: Boolean get() = selectedOption != null
    val isCorrectSelection: Boolean? get() =
        selectedOption?.let { it == currentQuestion?.sign?.label }
}

/**
 * Backs [QuizScreen]. FR-7 (Practice/Quiz Mode) — content-only matching
 * quiz, no camera/AI involved: a sign illustration is shown, the user
 * picks the matching label from [OPTIONS_PER_QUESTION] choices.
 *
 * Questions are (re)built once, in `init`, from the full static sign
 * catalog — a fresh random quiz every time this ViewModel is created
 * (i.e. every time the user opens Quiz from Home).
 */
@HiltViewModel
class QuizViewModel @Inject constructor(
    private val signRepository: SignRepository,
) : ViewModel() {

    private val _uiState = MutableStateFlow(QuizUiState(questions = buildQuestions()))
    val uiState: StateFlow<QuizUiState> = _uiState.asStateFlow()

    // Guards against saving the same attempt twice — e.g. if composition
    // recomposes around the "See Results" tap for any reason, only the
    // first call actually persists a row.
    private var hasSavedScore = false

    private fun buildQuestions(): List<QuizQuestion> {
        val allSigns = signRepository.getAllSigns()
        val chosenSigns = allSigns.shuffled().take(QUESTION_COUNT)

        return chosenSigns.map { correctSign ->
            val distractorLabels = allSigns
                .filter { it.id != correctSign.id }
                .map { it.label }
                .shuffled()
                .take(OPTIONS_PER_QUESTION - 1)

            QuizQuestion(
                sign = correctSign,
                options = (distractorLabels + correctSign.label).shuffled(),
            )
        }
    }

    /** Records the user's tapped answer; does nothing if this question was already answered. */
    fun selectAnswer(option: String) {
        _uiState.update { state ->
            if (state.hasAnswered) return@update state
            val isCorrect = option == state.currentQuestion?.sign?.label
            state.copy(
                selectedOption = option,
                score = if (isCorrect) state.score + 1 else state.score,
            )
        }
    }

    /** Advances to the next question, clearing the previous selection. Call only after an answer was given. */
    fun goToNextQuestion() {
        _uiState.update { state ->
            state.copy(
                currentIndex = (state.currentIndex + 1).coerceAtMost(state.questions.lastIndex),
                selectedOption = null,
            )
        }
    }

    /**
     * Persists this completed attempt to Room. Call exactly once, right
     * when the user taps "See Results" on the final question — not on
     * every answer, since a quiz attempt is one row, not one row per
     * question.
     */
    fun finishQuiz() {
        if (hasSavedScore) return
        hasSavedScore = true
        val state = _uiState.value
        viewModelScope.launch {
            signRepository.saveQuizScore(score = state.score, totalQuestions = state.questions.size)
        }
    }
}

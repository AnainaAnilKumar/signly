package com.signly.app.ui.alphabet

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.signly.app.data.model.SignCategory
import com.signly.app.data.model.SignItem
import com.signly.app.data.repository.SignRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.filterNotNull
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

/** One grid item: the static sign content plus whether it's been viewed. */
data class SignListEntry(
    val sign: SignItem,
    val isViewed: Boolean,
)

/**
 * Backs [AlphabetListScreen]. Content itself is static/synchronous
 * (`getSignsByCategory`), but the *viewed* flag per item is reactive —
 * it's read from Room via [SignRepository.observeAllProgress] so the grid's
 * checkmarks update live the moment a detail screen is opened, with no
 * manual refresh needed.
 */
@HiltViewModel
class AlphabetViewModel @Inject constructor(
    signRepository: SignRepository,
) : ViewModel() {

    private val alphabetSigns = signRepository.getSignsByCategory(SignCategory.ALPHABET)

    val entries: StateFlow<List<SignListEntry>> = signRepository.observeAllProgress()
        .map { progressList ->
            val viewedIds = progressList.filter { it.isViewed }.map { it.signId }.toSet()
            alphabetSigns.map { sign -> SignListEntry(sign, isViewed = sign.id in viewedIds) }
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = alphabetSigns.map { SignListEntry(it, isViewed = false) },
        )
}

/**
 * Backs [AlphabetDetailScreen]. Loads one sign by id, records it as
 * viewed the moment the screen opens, exposes prev/next neighbors so the
 * detail screen can step through the whole alphabet without returning to
 * the list each time, and tracks whether the current sign is favorited.
 */
@HiltViewModel
class AlphabetDetailViewModel @Inject constructor(
    private val signRepository: SignRepository,
) : ViewModel() {

    private val allAlphabetSigns = signRepository.getSignsByCategory(SignCategory.ALPHABET)

    private val _sign = MutableStateFlow<SignItem?>(null)
    val sign: StateFlow<SignItem?> = _sign.asStateFlow()

    /**
     * Re-subscribes to a NEW sign's favorite status every time [_sign]
     * changes (flatMapLatest cancels the previous sign's Flow collection
     * automatically) — without this, tapping Next/Previous would keep
     * showing the previous letter's favorite state for a moment.
     */
    val isFavorite: StateFlow<Boolean> = _sign
        .filterNotNull()
        .flatMapLatest { sign -> signRepository.observeIsFavorite(sign.id) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = false,
        )

    val previousSignId: String?
        get() = neighbor(-1)

    val nextSignId: String?
        get() = neighbor(+1)

    private fun neighbor(offset: Int): String? {
        val currentId = _sign.value?.id ?: return null
        val currentIndex = allAlphabetSigns.indexOfFirst { it.id == currentId }
        if (currentIndex == -1) return null
        val targetIndex = currentIndex + offset
        return allAlphabetSigns.getOrNull(targetIndex)?.id
    }

    fun loadSign(signId: String) {
        _sign.value = allAlphabetSigns.firstOrNull { it.id == signId }
        viewModelScope.launch {
            signRepository.markSignAsViewed(signId)
        }
    }

    fun markPracticed() {
        val signId = _sign.value?.id ?: return
        viewModelScope.launch {
            signRepository.markSignAsPracticed(signId)
        }
    }

    fun toggleFavorite() {
        val signId = _sign.value?.id ?: return
        viewModelScope.launch {
            signRepository.toggleFavorite(signId)
        }
    }
}

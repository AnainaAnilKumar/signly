package com.signly.app.ui.alphabet

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.SortByAlpha
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.signly.app.ui.common.EmptyState
import com.signly.app.ui.common.SignlyTopAppBar

/**
 * Alphabet List — a 4-column grid, one card per letter A-Z. Each card
 * shows the letter and, once viewed, a small checkmark badge in the
 * corner (read live from Room via the ViewModel — see AlphabetViewModel's
 * KDoc). Empty state is defensive-only: with static bundled content this
 * list can never actually be empty at runtime, but every list screen
 * still needs a defined empty state rather than silently rendering
 * nothing if that assumption is ever violated.
 */
@Composable
fun AlphabetListScreen(
    onSignClick: (String) -> Unit,
    onNavigateUp: () -> Unit,
    viewModel: AlphabetViewModel = hiltViewModel(),
) {
    val entries by viewModel.entries.collectAsState()

    Scaffold(
        topBar = { SignlyTopAppBar(title = "ISL Alphabet", onNavigateUp = onNavigateUp) },
    ) { innerPadding ->
        if (entries.isEmpty()) {
            EmptyState(
                icon = Icons.Filled.SortByAlpha,
                title = "No letters available",
                message = "Alphabet content couldn't be loaded. Try restarting the app.",
                modifier = Modifier.padding(innerPadding),
            )
            return@Scaffold
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = innerPadding.calculateTopPadding() + 16.dp,
                bottom = 16.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(entries, key = { it.sign.id }) { entry ->
                LetterCard(
                    label = entry.sign.label,
                    isViewed = entry.isViewed,
                    onClick = { onSignClick(entry.sign.id) },
                )
            }
        }
    }
}

@Composable
private fun LetterCard(
    label: String,
    isViewed: Boolean,
    onClick: () -> Unit,
) {
    Card(
        onClick = onClick,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(
            containerColor = if (isViewed) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            },
        ),
        modifier = Modifier.aspectRatio(1f),
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Text(
                text = label,
                style = MaterialTheme.typography.headlineSmall,
                color = if (isViewed) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.align(Alignment.Center),
            )
            if (isViewed) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = "Viewed",
                    tint = MaterialTheme.colorScheme.tertiary,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(6.dp)
                        .size(16.dp),
                )
            }
        }
    }
}

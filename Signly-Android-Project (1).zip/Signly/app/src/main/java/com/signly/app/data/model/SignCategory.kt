package com.signly.app.data.model

/**
 * The two (and only two, per the SRS scope) content categories in Signly.
 * Adding a new category later (e.g. NUMBER) means adding one enum entry
 * plus its data set — the rest of the architecture (repository, ViewModels,
 * navigation) is written generically against SignItem and does not need
 * per-category branching.
 */
enum class SignCategory {
    ALPHABET,
    GREETING,
}

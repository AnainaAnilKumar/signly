# Signly — Project Structure Reference

## Build configuration
| File | Belongs to |
|---|---|
| `settings.gradle.kts` | Project root — module list, repositories |
| `build.gradle.kts` | Project root — shared plugin declarations |
| `gradle.properties` | Project root — JVM/AndroidX/Kotlin flags |
| `gradle/libs.versions.toml` | Version catalog — every dependency version in one place |
| `gradle/wrapper/gradle-wrapper.properties` | Pins the Gradle version |
| `app/build.gradle.kts` | `:app` module — Android config + dependencies |
| `app/proguard-rules.pro` | `:app` module — release build shrink/obfuscate rules |

## App module — `app/src/main/`
| Path | Belongs to |
|---|---|
| `AndroidManifest.xml` | App/activity registration, no permissions declared |
| `res/values/strings.xml` | User-facing text |
| `res/values/colors.xml` | Launcher icon color only (Compose owns in-app colors) |
| `res/values/themes.xml` | Window-level XML theme (pre-Compose) |
| `res/xml/backup_rules.xml`, `res/xml/data_extraction_rules.xml` | Manifest-referenced backup config |
| `res/drawable/ic_launcher_*.xml`, `res/mipmap-anydpi-v26/` | Placeholder adaptive launcher icon |

## Kotlin source — `app/src/main/java/com/signly/app/`
| Path | Belongs to |
|---|---|
| `SignlyApplication.kt` | Hilt entry point |
| `MainActivity.kt` | Single Activity, hosts the NavHost |
| `data/model/` | `SignItem`, `SignCategory` — plain data classes |
| `data/source/SignDataSource.kt` | Hardcoded static content (26 letters + 10 greetings) |
| `data/local/entity/SignProgressEntity.kt` | Room table definition |
| `data/local/dao/SignProgressDao.kt` | Room queries |
| `data/local/SignlyDatabase.kt` | Room database class |
| `data/repository/SignRepository.kt` | Repository interface (what ViewModels depend on) |
| `data/repository/SignRepositoryImpl.kt` | Repository implementation |
| `di/DatabaseModule.kt` | Hilt: provides Room database + DAO |
| `di/RepositoryModule.kt` | Hilt: binds repository interface to impl |
| `ui/theme/` | Material 3 Color.kt / Type.kt / Theme.kt |
| `ui/navigation/Screen.kt` | All route definitions |
| `ui/navigation/SignlyNavGraph.kt` | NavHost wiring routes to screens |
| `ui/home/HomeScreen.kt` | Placeholder screen |
| `ui/alphabet/AlphabetViewModel.kt` | List + Detail ViewModels for Alphabet |
| `ui/alphabet/AlphabetScreens.kt` | Placeholder list/detail screens |
| `ui/greetings/GreetingViewModel.kt` | List + Detail ViewModels for Greetings |
| `ui/greetings/GreetingScreens.kt` | Placeholder list/detail screens |

## UI design pass — added this phase
| Path | Belongs to |
|---|---|
| `ui/theme/Color.kt` | Brand palette (Purple/Light Purple/Yellow/Navy) mapped to M3 roles |
| `ui/theme/Shape.kt` | Rounded-corner scale used by every card/button |
| `ui/theme/Type.kt` | Full type scale (was a 5-role stub, now covers every screen) |
| `ui/common/CommonComponents.kt` | SignlyTopAppBar, LoadingState, EmptyState, ProgressBadge — shared across all screens |
| `ui/splash/SplashScreen.kt` | Splash |
| `ui/home/HomeScreen.kt` + `HomeViewModel.kt` | Home |
| `ui/alphabet/AlphabetListScreen.kt` | Alphabet grid |
| `ui/alphabet/AlphabetDetailScreen.kt` | Alphabet detail + prev/next |
| `ui/greetings/GreetingsListScreen.kt` | Greetings list |
| `ui/greetings/GreetingDetailScreen.kt` | Greeting detail + prev/next |
| `ui/quiz/QuizScreen.kt` + `QuizViewModel.kt` | Quiz |
| `ui/quiz/ResultScreen.kt` | Result (no ViewModel — pure nav-arg summary) |
| `ui/progress/ProgressScreen.kt` + `ProgressViewModel.kt` | Progress |
| `ui/settings/SettingsScreen.kt` + `SettingsViewModel.kt` | Settings |
| `ui/navigation/SignlyNavGraph.kt` | `SignlyRoot` (Scaffold + bottom nav) + `SignlyNavGraph` (NavHost, all 10 routes) |

Also added this phase: `SignProgressDao.clearAll()` / `SignRepository.clearAllProgress()` (backs Settings' Reset Progress), and `HomeViewModel`/`ProgressViewModel` reading live Room progress.

**Not yet done, by design:** dark-mode toggle in Settings is in-memory only (no DataStore dependency added yet — noted as a TODO in `SettingsViewModel`); per-sign illustrations are still the placeholder launcher glyph (`SignDataSource`'s `imageRes` TODOs from the previous phase are unchanged — real artwork is a content/asset task, not a UI-structure one).

## Known gap before this opens/builds in Android Studio
`gradlew`, `gradlew.bat`, and `gradle/wrapper/gradle-wrapper.jar` are not
included (the wrapper jar is a binary this environment cannot fetch —
`services.gradle.org` isn't reachable from here). Opening this folder in
Android Studio will prompt to regenerate the wrapper automatically; or run
`gradle wrapper --gradle-version 8.9` once from a machine with Gradle
installed.
